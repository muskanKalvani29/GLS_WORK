//
//  DeleteCollectionSecondController.swift
//  CoreDataInDelDemoTbl
//
//  Created by exam on 10/11/22.
//  Copyright © 2022 GLS. All rights reserved.
//

import UIKit

class DeleteCollectionSecondController: UIViewController {

    @IBOutlet weak var team: UILabel!
    @IBOutlet weak var name: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        let appDel = UIApplication.shared.delegate as! AppDelegate
        name.text = appDel.platerData[appDel.selectedIndex].value(forKey: "name") as! String
        team.text = appDel.platerData[appDel.selectedIndex].value(forKey: "team") as! String

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    @IBAction func deleteAction(_ sender: Any)
    {
        let appDel = UIApplication.shared.delegate as! AppDelegate
        let context = appDel.persistentContainer.viewContext
        context.delete(appDel.platerData[appDel.selectedIndex])
        do {
            try context.save()
        } catch let error as NSError {
            print(error)
        }
        
        appDel.platerData.remove(at: appDel.selectedIndex)
        self.navigationController?.popViewController(animated: true)
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
