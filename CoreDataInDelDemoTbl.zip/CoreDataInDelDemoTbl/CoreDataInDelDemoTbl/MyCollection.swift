//
//  MyCollection.swift
//  CoreDataInDelDemoTbl
//
//  Created by exam on 10/11/22.
//  Copyright © 2022 GLS. All rights reserved.
//

import UIKit

class MyCollection: UICollectionViewCell
{
        
    @IBOutlet weak var player_team: UILabel!
    @IBOutlet weak var player_name: UILabel!
}
