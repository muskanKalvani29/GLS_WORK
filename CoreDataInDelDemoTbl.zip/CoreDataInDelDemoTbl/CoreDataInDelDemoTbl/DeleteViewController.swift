//
//  DeleteViewController.swift
//  CoreDataInDelDemoTbl
//
//  Created by exam on 10/11/22.
//  Copyright © 2022 GLS. All rights reserved.
//

import UIKit

class DeleteViewController: UIViewController {

    @IBOutlet weak var p_team: UILabel!
    @IBOutlet weak var p_name: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()

        let appDel = UIApplication.shared.delegate as! AppDelegate
        
        p_name.text = appDel.platerData[appDel.selectedIndex].value(forKey: "name") as! String
        p_team.text = appDel.platerData[appDel.selectedIndex].value(forKey: "team") as! String
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
    @IBAction func DeleteAction(_ sender: Any)
    {
        let appDel = UIApplication.shared.delegate as! AppDelegate
        let contex = appDel.persistentContainer.viewContext
        
        contex.delete(appDel.platerData[appDel.selectedIndex])
        do {
            try contex.save()
        } catch let error as NSError {
            print(error)
        }
        
        //also delete record from array
        appDel.platerData.remove(at: appDel.selectedIndex)
        
        self.navigationController?.popViewController(animated: true)
    }

}
