//
//  ViewController.swift
//  CoreDataInDelDemoTbl
//
//  Created by Vishal Narvani on 17/10/22.
//  Copyright © 2022 GLS. All rights reserved.
//

import UIKit
import CoreData


class ViewController: UIViewController {
    @IBOutlet weak var txtColor: UITextField!

    @IBOutlet weak var txtName: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    @IBAction func actionSave(_ sender: Any)
    {
        let appDel = UIApplication.shared.delegate as! AppDelegate
        let managedContext = appDel.persistentContainer.viewContext
        let entityCar = NSEntityDescription.entity(forEntityName: "Car", in: managedContext)

        
        let managedObject = NSManagedObject(entity: entityCar!, insertInto: managedContext)
        
        managedObject.setValue(txtName.text, forKey: "name")
        managedObject.setValue(txtColor.text, forKey: "color")
        
        
        
        do {
            try managedContext.save()
        } catch let err as NSError {
            print(err)
        }
    }
    
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

