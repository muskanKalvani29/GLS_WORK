//
//  SecondVC.swift
//  CoreDataInDelDemoTbl
//
//  Created by Vishal Narvani on 17/10/22.
//  Copyright © 2022 GLS. All rights reserved.
//

import UIKit
import CoreData

class SecondVC: UIViewController,UITableViewDelegate,UITableViewDataSource {

    @IBOutlet weak var tblViewCars: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        print("viewdidload")
        let appDel = UIApplication.shared.delegate as! AppDelegate
        
        let context = appDel.persistentContainer.viewContext
        
        let fetchReq = NSFetchRequest<NSManagedObject>(entityName: "Car")
        
        do {
            try appDel.arrCars = context.fetch(fetchReq)
            print(appDel.arrCars.count)
        } catch let err as NSError {
            print(err)
        }
        
        
        
        
        // Do any additional setup after loading the view.
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        let appDel = UIApplication.shared.delegate as! AppDelegate
        return appDel.arrCars.count
    }
    
     func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
     {
        let appDel = UIApplication.shared.delegate as! AppDelegate
        let cell = tableView.dequeueReusableCell(withIdentifier: "MyCell") as! MyCell
        
        let singleRow = appDel.arrCars[indexPath.row]
        
        
        cell.lblName.text=String(describing: singleRow.value(forKey: "name")!)
        cell.lblColoe.text=(singleRow.value(forKey: "color")! as! String)
        
        return cell
        
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        print("Row at: \(indexPath.row) ")
        let appDel = UIApplication.shared.delegate as! AppDelegate
        let context = appDel.persistentContainer.viewContext
        
        
        context.delete(appDel.arrCars[indexPath.row])
        
        do {
            try context.save()
        } catch let err as NSError {
            print(err)
        }

        
        appDel.arrCars.remove(at: indexPath.row)
        tableView.reloadData()
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
   
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let appDel = UIApplication.shared.delegate as! AppDelegate
        appDel.selectedIndex = indexPath.row
        self.performSegue(withIdentifier: "wayToDetail", sender: self)
    }
    override func viewWillAppear(_ animated: Bool) {
        
        print("viewDidAppear")
        tblViewCars.reloadData()
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
