//
//  DataViewController.swift
//  CoreDataInDelDemoTbl
//
//  Created by exam on 10/11/22.
//  Copyright © 2022 GLS. All rights reserved.
//

import UIKit
import CoreData

class DataViewController: UIViewController,UITableViewDataSource,UITableViewDelegate {

    @IBOutlet weak var tabelView: UITableView!
    var appDel:AppDelegate! = nil
    override func viewDidLoad() {
        super.viewDidLoad()

        appDel = UIApplication.shared.delegate as! AppDelegate
        let context = appDel.persistentContainer.viewContext
        let fetchReq = NSFetchRequest<NSManagedObject>(entityName: "Player")
        
        do {
            try appDel.platerData = context.fetch(fetchReq)
                print(appDel.platerData.count)
        } catch let error as NSError {
            print(error)
        }
        
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return appDel.platerData.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tabelView.dequeueReusableCell(withIdentifier: "MyCellPlayer", for: indexPath) as! MyCellPlayer
        cell.pName.text = appDel.platerData[indexPath.row].value(forKey: "name") as! String
        cell.pTeam.text = appDel.platerData[indexPath.row].value(forKey: "team") as! String
        print(cell.pName.text!)
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath)
    {
            appDel.selectedIndex = indexPath.row
            self.performSegue(withIdentifier: "gotonextPage" , sender: self)
        
    }
    
    //for refresh the data
    override func viewWillAppear(_ animated: Bool) {
        tabelView.reloadData()
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        appDel = UIApplication.shared.delegate as! AppDelegate
        let context = appDel.persistentContainer.viewContext
        
        context.delete(appDel.platerData[indexPath.row])
        
        do {
            try context.save()
        } catch let error as NSError {
            print(error)
        }
        
        appDel.platerData.remove(at: indexPath.row)
        tabelView.reloadData()
        
    }
    
}
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */


