//
//  DataViewController.swift
//  CoreDataInDelDemoTbl
//
//  Created by exam on 10/11/22.
//  Copyright © 2022 GLS. All rights reserved.
//

import UIKit
import CoreData

class DataViewController: UIViewController,UITableViewDataSource,UITableViewDelegate {

    @IBOutlet weak var tabelView: UITableView!
    var appDel:AppDelegate! = nil
    override func viewDidLoad() {
        super.viewDidLoad()

        appDel = UIApplication.shared.delegate as! AppDelegate
        let context = appDel.persistentContainer.viewContext
        let fetchReq = NSFetchRequest<NSManagedObject>(entityName: "Player")
        
        do {
            try appDel.platerData = context.fetch(fetchReq)
                print(appDel.platerData.count)
        } catch let error as NSError {
            print(error)
        }
        
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return appDel.platerData.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tabelView.dequeueReusableCell(withIdentifier: <#T##String#>, for: <#T##IndexPath#>)
        
        }
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
