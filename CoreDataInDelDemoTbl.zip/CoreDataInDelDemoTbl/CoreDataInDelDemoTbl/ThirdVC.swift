//
//  ThirdVC.swift
//  CoreDataInDelDemoTbl
//
//  Created by Vishal Narvani on 17/10/22.
//  Copyright © 2022 GLS. All rights reserved.
//

import UIKit

class ThirdVC: UIViewController {

    @IBOutlet weak var lblColor: UILabel!
    @IBOutlet weak var lblName: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let appDel = UIApplication.shared.delegate as! AppDelegate
        var selectedRow = appDel.arrCars[appDel.selectedIndex]
        lblName.text = (selectedRow.value(forKey: "name")! as! String)
        lblColor.text = (selectedRow.value(forKey: "color")! as! String)

        // Do any additional setup after loading the view.
    }

    @IBAction func actionDelete(_ sender: Any)
    {
        let appDel = UIApplication.shared.delegate as! AppDelegate
        let context = appDel.persistentContainer.viewContext
        
        
        context.delete(appDel.arrCars[appDel.selectedIndex])
        
        do {
            try context.save()
        } catch let err as NSError {
            print(err)
        }
        
        
        appDel.arrCars.remove(at: appDel.selectedIndex)
        
        self.navigationController?.popViewController(animated: true)

    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
