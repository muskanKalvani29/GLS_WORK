//
//  DeleteCollectionViewController.swift
//  CoreDataInDelDemoTbl
//
//  Created by exam on 10/11/22.
//  Copyright © 2022 GLS. All rights reserved.
//

import UIKit
import CoreData

class DeleteCollectionViewController: UIViewController,UICollectionViewDataSource,UICollectionViewDelegate {

    @IBOutlet weak var cell: UICollectionView!
    var appDel:AppDelegate! = nil
    override func viewDidLoad() {
        super.viewDidLoad()
        appDel = UIApplication.shared.delegate as! AppDelegate
        let context = appDel.persistentContainer.viewContext
        let fetchReq = NSFetchRequest<NSManagedObject>(entityName: "Player")
        do {
            try appDel.platerData = context.fetch(fetchReq)
        } catch let error as NSError {
            print(error)
        }
        
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        appDel = UIApplication.shared.delegate as! AppDelegate
        return appDel.platerData.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        appDel = UIApplication.shared.delegate as! AppDelegate
        let mycell = cell.dequeueReusableCell(withReuseIdentifier: "MyCollection", for: indexPath) as! MyCollection
        mycell.player_name.text = appDel.platerData[indexPath.row].value(forKey: "name") as! String
        mycell.player_team.text = appDel.platerData[indexPath.row].value(forKey: "team") as! String
        return mycell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        appDel.selectedIndex = indexPath.row
        self.performSegue(withIdentifier: "gotoCollection", sender: self)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        cell.reloadData()
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
