package com.example.sqllitedemo;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

public class SecondSceen extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second_sceen);

        ArrayList<String> rollNoList = this.getIntent().getStringArrayListExtra("rollNoList");
        ArrayList<String> nameList = this.getIntent().getStringArrayListExtra("nameList");
        ArrayList<String> courseList = this.getIntent().getStringArrayListExtra("courseList");
        ArrayList<String> semList = this.getIntent().getStringArrayListExtra("semList");

        ListView list = findViewById(R.id.studentList);
        CustomAdapter obj = new CustomAdapter(getApplicationContext(),rollNoList,nameList,courseList,semList);
        list.setAdapter(obj);


    }
}

class CustomAdapter extends BaseAdapter
{
    Context context;
    ArrayList<String> rollNoList;
    ArrayList<String> nameList;
    ArrayList<String> courseList;
    ArrayList<String> semList;
    LayoutInflater myinflate;

    CustomAdapter(Context context,ArrayList<String> rollNoList,ArrayList<String> nameList,ArrayList<String> courseList,ArrayList<String> semList)
    {
        this.context = context;
        this.rollNoList = rollNoList;
        this.nameList = nameList;
        this.courseList = courseList;
        this.semList = semList;
        myinflate = (LayoutInflater.from(context));
    }

    @Override
    public int getCount() {
        return rollNoList.size();
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        convertView = myinflate.inflate(R.layout.showstudentdata,null);
        TextView roll_no = convertView.findViewById(R.id.roll_no);
        TextView name = convertView.findViewById(R.id.Name);
        TextView course = convertView.findViewById(R.id.Course);
        TextView sem = convertView.findViewById(R.id.Sem);
        roll_no.setText(rollNoList.get(position));
        name.setText(nameList.get(position));
        course.setText(courseList.get(position));
        sem.setText(semList.get(position));
        return convertView;
    }
}
