package com.example.sqllitedemo;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    ArrayList<String> rollNoList = new ArrayList<>();
    ArrayList<String> nameList = new ArrayList<>();
    ArrayList<String> courseList = new ArrayList<>();
    ArrayList<String> semList = new ArrayList<>();
    SQLiteDatabase mDataBase;
    static String CREATE_STUDENT_TABLE;
    final static String STUDENT_TABLE = "tblStudents";

    @SuppressLint("WrongConstant")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final EditText id = findViewById(R.id.id);
        final EditText name = findViewById(R.id.name);
        final EditText course = findViewById(R.id.course);
        final EditText sem = findViewById(R.id.sem);

        Button submit = findViewById(R.id.submit);
        Button showButton = findViewById(R.id.show);

        showButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Cursor c = mDataBase.query(STUDENT_TABLE,null,null,null,null,null,null,null);

                c.moveToFirst();
                while(c.isAfterLast()==false)
                {
                    rollNoList.add(c.getString(0));
                    nameList.add(c.getString(1));
                    courseList.add(c.getString(2));
                    semList.add(c.getString(3));
                    c.moveToNext();
                }

                Intent in = new Intent(MainActivity.this,SecondSceen.class);
                in.putStringArrayListExtra("rollNoList",rollNoList);
                in.putStringArrayListExtra("nameList",nameList);
                in.putStringArrayListExtra("courseList",courseList);
                in.putStringArrayListExtra("semList",semList);
                startActivity(in);
            }
        });
        
        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                
                String s_id = id.getText().toString();
                String s_name = name.getText().toString();
                String s_course = course.getText().toString();
                String s_sem = sem.getText().toString();
                insertData(s_id,s_name,s_course,s_sem);
            }
        });

        mDataBase = openOrCreateDatabase("Student.db",SQLiteDatabase.CREATE_IF_NECESSARY,null);
        try{
            CREATE_STUDENT_TABLE = "CREATE TABLE IF NOT EXISTS tblStudents("+"id TEXT PRIMARY KEY,"+"name TEXT,"+"course TEXT,"+"semester TEXT"+")";
            mDataBase.execSQL(CREATE_STUDENT_TABLE);


        }catch(Exception e)
        {
            Toast.makeText(this, e.getMessage(), Toast.LENGTH_SHORT).show();
        }

    }

    private void insertData(String s_id, String s_name, String s_course, String s_sem) {
        ContentValues values = new ContentValues();
        values.put("id",s_id);
        values.put("name",s_name);
        values.put("course",s_course);
        values.put("semester",s_sem);
        mDataBase.insert(STUDENT_TABLE,null,values);
        Toast.makeText(this, "Data Addd Successfully", Toast.LENGTH_SHORT).show();
    }



}