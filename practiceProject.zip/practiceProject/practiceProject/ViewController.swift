//
//  ViewController.swift
//  practiceProject
//
//  Created by exam on 07/10/22.
//  Copyright © 2022 GLS. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var count: UILabel!
    @IBOutlet weak var marks: UITextField!
    @IBOutlet weak var name: UITextField!
    var appDel = UIApplication.shared.delegate as! AppDelegate
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    @IBAction func showDataAction(_ sender: Any) {
        performSegue(withIdentifier: "gotoNext", sender: self)
    }

    @IBAction func AddDataAction(_ sender: Any)
    {
        var stuobj = Student()
        stuobj.name = name.text!
        stuobj.marks = Int(marks.text!)!	
        appDel.studentData.append(stuobj)
        count.text = String(appDel.studentData.count)
    
    }
}

