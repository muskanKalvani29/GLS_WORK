//
//  Student.swift
//  practiceProject
//
//  Created by exam on 07/10/22.
//  Copyright © 2022 GLS. All rights reserved.
//

import UIKit

class Student: NSObject {

    var name=""
    var marks=0
}
