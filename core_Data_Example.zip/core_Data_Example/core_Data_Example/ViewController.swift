//
//  ViewController.swift
//  core_Data_Example
//
//  Created by exam on 07/10/22.
//  Copyright © 2022 GLS. All rights reserved.
//

import UIKit
import CoreData

class ViewController: UIViewController {

    
    @IBOutlet weak var rollNo: UITextField!
    @IBOutlet weak var name: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func addDataAction(_ sender: Any)
    {
        // object of appdelegate
        let appDel = UIApplication.shared.delegate as! AppDelegate
        //object of helper class
        let conext = appDel.persistentContainer.viewContext
        
        // entity object
        let entity = NSEntityDescription.entity(forEntityName: "Student", in: conext)
        //raw object
        let student_raw = NSManagedObject(entity: entity!, insertInto :conext)
        
        student_raw.setValue(name.text, forKey: "name")
        student_raw.setValue(rollNo.text, forKey: "rollNo")
        do {
            try conext.save()
            print("added")
        } catch let err as NSError {
            print(err)
        }
    }
    
    
    @IBAction func showDataAction(_ sender: Any)
    {
        performSegue(withIdentifier: "gotoNext", sender: self)
    }
    
    

}

