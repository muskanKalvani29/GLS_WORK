//
//  SecondViewController.swift
//  core_Data_Example
//
//  Created by exam on 07/10/22.
//  Copyright © 2022 GLS. All rights reserved.
//

import UIKit
import CoreData


class SecondViewController: UIViewController ,UITableViewDataSource{

    var appDel:AppDelegate! = nil
    override func viewDidLoad() {
        super.viewDidLoad()
        appDel = UIApplication.shared.delegate as! AppDelegate
        let context = appDel.persistentContainer.viewContext
        let fetchReq = NSFetchRequest<NSManagedObject>(entityName: "Student")
        do {
            try appDel.arr = context.fetch(fetchReq)
            
        } catch let err as NSError {
            print(err)
        }
        
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return appDel.arr.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var cell = tableView.dequeueReusableCell(withIdentifier: "myCell", for: indexPath) as! myCell
        cell.name.text = appDel.arr[indexPath.row].value(forKey: "name") as! String
        cell.marks.text  = appDel.arr[indexPath.row].value(forKey: "rollNo") as! String
        return cell
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
