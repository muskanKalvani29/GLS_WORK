//
//  myCell.swift
//  core_Data_Example
//
//  Created by exam on 07/10/22.
//  Copyright © 2022 GLS. All rights reserved.
//

import UIKit

class myCell: UITableViewCell {

    @IBOutlet weak var marks: UILabel!
    @IBOutlet weak var name: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
