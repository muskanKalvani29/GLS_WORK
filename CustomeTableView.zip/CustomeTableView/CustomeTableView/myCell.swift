//
//  myCell.swift
//  CustomeTableView
//
//  Created by exam on 07/10/22.
//  Copyright © 2022 GLS. All rights reserved.
//

import UIKit

class myCell: UITableViewCell {

    @IBOutlet weak var stuMarks: UILabel!
    @IBOutlet weak var stuName: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
