//
//  SecondViewController.swift
//  CustomeTableView
//
//  Created by exam on 07/10/22.
//  Copyright © 2022 GLS. All rights reserved.
//

import UIKit

class SecondViewController: UIViewController,UITableViewDataSource {

    var appDel = UIApplication.shared.delegate as! AppDelegate
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return appDel.stuArr.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var cell = tableView.dequeueReusableCell(withIdentifier: "mycell", for: indexPath) as! myCell
        cell.stuName.text = appDel.stuArr[indexPath.row].name
        cell.stuMarks.text = String(appDel.stuArr[indexPath.row].marks)
        return cell
        
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
